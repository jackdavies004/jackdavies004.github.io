#from curses import mouseinterval
#from sys import displayhook
import pygame
import math
import asyncio
pygame.init()

# Declaring key global variables
main_menu = False
instructions_complete = False
positioning = False
run = True
player_lost = False
direction = "right"

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
blue = pygame.Color("#0e30b5")

flag = True
horizontal_velocity = 0.9
vertical_velocity = 4
movement_unlocked = False

character_width = 25
character_height = 80
enemy_width = 100
enemy_height = 100
coin_total = 0

# Image loading
full_health_img = pygame.image.load('full_health.png')
two_lives_img = pygame.image.load('two_hearts.png')
one_life_img = pygame.image.load('one_heart.png')
no_lives_img = pygame.image.load('no_lives.png')

floor = 450
wall = 810
over = False

gravity_speed = 1.5
shift_counter = 0

size = [800,550]
screen = pygame.display.set_mode(size)
pygame.Surface.convert(screen)
pygame.display.set_caption("Tempest")

ground_tiles = math.ceil(size[0] / size[1]) + 1 
ground = pygame.image.load('ground.png').convert_alpha()
ground_width = ground.get_width()
ground_scroll = 0
background_velocity = 0

done = False
clock = pygame.time.Clock()
instant_quit = False
passed = 0 

# Sound Effects
muted_jump_sfx = pygame.mixer.Sound("muted_jump.mp3")
mouse_click_sfx = pygame.mixer.Sound("mouse_click.mp3")
coin_collect_sfx = pygame.mixer.Sound("coin_collect.mp3")
level_complete_sfx = pygame.mixer.Sound("level_complete.mp3")
damage_sfx = pygame.mixer.Sound("damage.mp3")
game_over_sfx = pygame.mixer.Sound("game_over.mp3")



# A pause screen that can be activated when the user is playing
def pause():
    global positioning 
    global done
    global instant_quit
    global event
    global main_menu 
    global run
    global mouse_click_sfx
    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                instant_quit = True
                done = True
            if instant_quit == True:
                break
        
        pause_img = pygame.image.load('paused.png')
        main_menu_img = pygame.image.load('main_menu.png')
        main_menu_highlighted_img = pygame.image.load('main_menu_highlighted.png')
        resume_img = pygame.image.load('resume.png')
        resume_highlighted_img = pygame.image.load('resume_highlighted.png')
        quit_game_img = pygame.image.load('quit_game.png')
        quit_game_highlighted_img = pygame.image.load('quit_game_highlighted.png') 
        screen.fill(blue)
        screen.blit(pause_img, (175,15))
        
        highlight_pos = pygame.mouse.get_pos()
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            # Resume game
            if pos[0] > 232 and pos[0] < 572 and pos[1] > 150 and pos[1] < 187:
                mouse_click_sfx.play()
                break
            # Main menu
            elif pos[0] > 260 and pos[0] < 545 and pos[1] > 250 and pos[1] < 290:
                main_menu = True
                mouse_click_sfx.play()
                break
            # Quit game
            if pos[0] > 270 and pos[0] < 530 and pos[1] > 400 and pos[1] < 435:
                instant_quit = True
                done = True
                run = False
                mouse_click_sfx.play()
                return True
                
        if highlight_pos[0] > 232 and highlight_pos[0] < 572 and highlight_pos[1] > 150 and highlight_pos[1] < 187:
            screen.blit(resume_highlighted_img, (232,150))
        else:
            screen.blit(resume_img, (232,150))

        if highlight_pos[0] > 260 and highlight_pos[0] < 545 and highlight_pos[1] > 250 and highlight_pos[1] < 290:
            screen.blit(main_menu_highlighted_img, (260,250))
        else:
            screen.blit(main_menu_img, (260,250))
        
        if highlight_pos[0] > 270 and highlight_pos[0] < 530 and highlight_pos[1] > 400 and highlight_pos[1] < 435:
            screen.blit(quit_game_highlighted_img, (270,400))
        else:
            screen.blit(quit_game_img, (270,400))

        pygame.display.update()


# Instruction screen
def instructions():
    global done
    global instant_quit
    global event
    global run
    global instructions_complete
    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                instant_quit = True
                done = True
            if instant_quit == True:
                break
        keys = pygame.key.get_pressed()
        instruction_img = pygame.image.load("instructions.png")
        screen.blit(instruction_img, (-35,0))
        
        # When space is pressed, move to the actual game
        if keys[pygame.K_SPACE]:
            instructions_complete = True
            break
            
        pygame.display.update()


# Main Menu (formerly loading_screen)
def loading_screen():
    global positioning 
    global done
    global instant_quit
    global event
    global run
    global main_menu
    global mouse_click_sfx
    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
                run = False
                instant_quit = True 
            if instant_quit == True:
                break
        
        main_menu = False
        title_img = pygame.image.load('title.png')
        select_level_img = pygame.image.load('select_level.png') # Acting as "Start Game" now
        select_level_highlighted_img = pygame.image.load('select_level_highlighted.png')
        quit_game_img = pygame.image.load('quit_game.png')
        quit_game_highlighted_img = pygame.image.load('quit_game_highlighted.png')
        
        screen.fill(blue)
        screen.blit(title_img, (170,10))
        
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            # Start Game (clicking the select level button)
            if pos[0] > 235 and pos[0] < 575 and pos[1] > 300 and pos[1] < 335:
                mouse_click_sfx.play()
                positioning = True
                break
            # Quit game
            elif pos[0] > 270 and pos[0] < 530 and pos[1] > 400 and pos [1] < 437:
                mouse_click_sfx.play()
                done = True
                run = False
                instant_quit = True 
                break

        highlight_pos = pygame.mouse.get_pos()
        
        # Start Game Hover
        if highlight_pos[0] > 235 and highlight_pos[0] < 575 and highlight_pos[1] > 300 and highlight_pos[1] < 335:
            screen.blit(select_level_highlighted_img, (235,300))
        else:
            screen.blit(select_level_img, (235,300))
            
        # Quit Game Hover
        if highlight_pos[0] > 270 and highlight_pos[0] < 530 and highlight_pos[1] > 400 and highlight_pos[1] < 437:
            screen.blit(quit_game_highlighted_img, (270,400))
        else:
            screen.blit(quit_game_img, (270,400))

        pygame.display.update()


def game_over():
    global positioning 
    global done
    global instant_quit
    global event
    global run
    global main_menu
    global player_lost
    global mouse_click_sfx
    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
                run = False
                instant_quit = True
                
        if instant_quit == True or main_menu == True:
            break
            
        quit_game_img = pygame.image.load('quit_game.png')
        quit_game_highlighted_img = pygame.image.load('quit_game_highlighted.png')
        main_menu_img = pygame.image.load('main_menu.png')
        main_menu_highlighted_img = pygame.image.load('main_menu_highlighted.png')
        game_over_img = pygame.image.load('game_over.png')
        level_complete_img = pygame.image.load('level_complete.png')
        
        screen.fill(blue)
        
        if player_lost == True:
            screen.blit(game_over_img, (175,15))
        else:
            screen.blit(level_complete_img, (135,15))
            
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            # Quit game
            if pos[0] > 270 and pos[0] < 520 and pos[1] > 320 and pos[1] < 357:
                mouse_click_sfx.play()
                run = False
                instant_quit = True
                done = True
            # Main menu
            elif pos[0] > 260 and pos[0] < 510 and pos[1] > 220 and pos[1] < 260:
                mouse_click_sfx.play()
                main_menu = True
                break
        else:
            highlight_pos2 = pygame.mouse.get_pos()
            if highlight_pos2[0] > 270 and highlight_pos2[0] < 527 and highlight_pos2[1] > 320 and highlight_pos2[1] < 357:
                screen.blit(quit_game_highlighted_img, (270,320))
            else:
                screen.blit(quit_game_img, (270, 320))
            
            if highlight_pos2[0] > 260 and highlight_pos2[0] < 540 and highlight_pos2[1] > 220 and highlight_pos2[1] < 260:
                screen.blit(main_menu_highlighted_img, (262,220))
            else:
                screen.blit(main_menu_img, (260,220))
                
        pygame.display.update()
    

# Creating an object for a character
class Character:    
    def __init__(self, name, spriteFileName,x,y,jumping,lives):
        self.name = name
        self.spriteFileName = spriteFileName
        self.x = x
        self.y = y
        self.jumping = jumping
        self.sprites_idle = []
        self.sprites_run_right = []
        self.sprites_run_left = []
        self.lives = lives
        
        idle1_img = pygame.image.load("character_idle1.png")
        idle2_img = pygame.image.load("character_idle2.png")
        idle3_img = pygame.image.load("character_idle3.png")
        idle4_img = pygame.image.load("character_idle4.png")
        idle1_img_resized = pygame.transform.scale(idle1_img, (40,80))
        idle2_img_resized = pygame.transform.scale(idle2_img, (40,80))
        idle3_img_resized = pygame.transform.scale(idle3_img, (40,80))
        idle4_img_resized = pygame.transform.scale(idle4_img, (40,80))

        for i in range(22): self.sprites_idle.append(idle1_img_resized)
        for i in range(22): self.sprites_idle.append(idle2_img_resized)
        for i in range(22): self.sprites_idle.append(idle3_img_resized)
        for i in range(22): self.sprites_idle.append(idle4_img_resized)
        self.current_idle_sprite = 0

        right1_img = pygame.image.load("character_run_right1.png")
        right2_img = pygame.image.load("character_run_right2.png")
        right3_img = pygame.image.load("character_run_right3.png")
        right4_img = pygame.image.load("character_run_right4.png")
        right5_img = pygame.image.load("character_run_right5.png")
        right6_img = pygame.image.load("character_run_right6.png")
        right_run1_img_resized = pygame.transform.scale(right1_img, (52,80))
        right_run2_img_resized = pygame.transform.scale(right2_img, (40,80))
        right_run3_img_resized = pygame.transform.scale(right3_img, (54,80))
        right_run4_img_resized = pygame.transform.scale(right4_img, (53,80))
        right_run5_img_resized = pygame.transform.scale(right5_img, (40,80))
        right_run6_img_resized = pygame.transform.scale(right6_img, (52,80))

        for i in range(10): self.sprites_run_right.append(right_run1_img_resized)
        for i in range(10): self.sprites_run_right.append(right_run2_img_resized)
        for i in range(10): self.sprites_run_right.append(right_run3_img_resized)
        for i in range(10): self.sprites_run_right.append(right_run4_img_resized)
        for i in range(10): self.sprites_run_right.append(right_run5_img_resized)
        for i in range(10): self.sprites_run_right.append(right_run6_img_resized)
        self.current_run_sprite = 0

        left1_img = pygame.image.load("character_run_left1.png")
        left2_img = pygame.image.load("character_run_left2.png")
        left3_img = pygame.image.load("character_run_left3.png")
        left4_img = pygame.image.load("character_run_left4.png")
        left5_img = pygame.image.load("character_run_left5.png")
        left6_img = pygame.image.load("character_run_left6.png")
        left_run1_img_resized = pygame.transform.scale(left1_img, (52,80))
        left_run2_img_resized = pygame.transform.scale(left2_img, (40,80))
        left_run3_img_resized = pygame.transform.scale(left3_img, (54,80))
        left_run4_img_resized = pygame.transform.scale(left4_img, (53,80))
        left_run5_img_resized = pygame.transform.scale(left5_img, (40,80))
        left_run6_img_resized = pygame.transform.scale(left6_img, (52,80))

        for i in range(10): self.sprites_run_left.append(left_run1_img_resized)
        for i in range(10): self.sprites_run_left.append(left_run2_img_resized)
        for i in range(10): self.sprites_run_left.append(left_run3_img_resized)
        for i in range(10): self.sprites_run_left.append(left_run4_img_resized)
        for i in range(10): self.sprites_run_left.append(left_run5_img_resized)
        for i in range(10): self.sprites_run_left.append(left_run6_img_resized)
        self.current_run_left_sprite = 0
        self.pario_img = self.sprites_idle[self.current_idle_sprite]

    def blit (self, x, y):
        self.x = x
        self.y = y
        screen.blit(self.pario_img, (x, y))

    def idle(self):
        self.current_idle_sprite += 1
        self.pario_img = self.sprites_idle[self.current_idle_sprite] 
        if self.current_idle_sprite >= len(self.sprites_idle) -1:
            self.current_idle_sprite = 0

    def right_run(self):
        self.current_run_sprite += 1
        self.pario_img = self.sprites_run_right[self.current_run_sprite] 
        if self.current_run_sprite >= len(self.sprites_run_right) -1:
            self.current_run_sprite = 0

    def left_run(self):
        self.current_run_left_sprite += 1
        self.pario_img = self.sprites_run_left[self.current_run_left_sprite] 
        if self.current_run_left_sprite >= len(self.sprites_run_left) -1:
            self.current_run_left_sprite = 0
            
    def jump(self):
        global direction
        jump_right_img = pygame.image.load("character_jump.png")
        jump_left_img = pygame.image.load("character_jump_left.png")
        jump_right_resized_img = pygame.transform.scale(jump_right_img, (40,80))
        jump_left_resized_img = pygame.transform.scale(jump_left_img, (40,80))
        if direction == "right":
            self.pario_img = jump_right_resized_img
        elif direction == "left":
            self.pario_img = jump_left_resized_img

    def gravity(self,fall):
        global gravity_speed
        self.fall = fall
        fall = True
        if self.y < floor - character_height and self.fall == True:
            self.y += gravity_speed
            self.jumping = True
        else:
            self.jumping = False

    def movement(self,flag):
        global direction
        global gravity_speed
        global movement_unlocked
        if movement_unlocked == False:
            if keys[pygame.K_a] and self.x > 0:
                self.x -= horizontal_velocity
                flag = True
                direction = "left"
            if keys[pygame.K_d] and self.x < wall - character_width and self.x <= 500:
                self.x += horizontal_velocity
                flag = True
                direction = "right"
            if keys[pygame.K_w] and self.y > 0:
                self.y -= vertical_velocity 
                flag = True
            else:
                flag = False
                return flag
        elif movement_unlocked == True:
            if keys[pygame.K_a] and self.x > 0:
                self.x -= horizontal_velocity
                flag = True
                direction = "left"
            if keys[pygame.K_d] and self.x < wall - character_width:
                self.x += horizontal_velocity
                flag = True
                direction = "right"
            if keys[pygame.K_w] and self.y > 0:
                self.y -= vertical_velocity 
                flag = True
            else:
                flag = False
                return flag
      

pario = Character("Pario","wanderer_idle1.png",200,260,False,60)

def health(pario):
    if pario.lives <= 60 and pario.lives > 40:
        screen.blit(full_health_img, (625,10))
    if pario.lives <= 40 and pario.lives > 20:
        screen.blit(two_lives_img, (625,10))
    if pario.lives <= 20 and pario.lives > 0:
        screen.blit(one_life_img, (625,10))
    if pario.lives <= 0:
        screen.blit(no_lives_img, (625,10))

class Coin:
    def __init__(self,coin_x,coin_y,width,height,sprite,display):
        self.coin_x = coin_x
        self.coin_y = coin_y
        self.width = width
        self.height = height
        self.display = display
        self.coin_img = pygame.image.load(sprite)

    def blit(self,coin_x,coin_y):
        self.coin_x = coin_x
        self.coin_y = coin_y
        screen.blit(self.coin_img, (coin_x,coin_y))

    def collect(self):
        global coin_collect_sfx
        global coin_total
        global character_width
        if pario.x + character_width >= self.coin_x and pario.x <= self.coin_x + self.width and pario.y + character_height >= self.coin_y and pario.y <= self.coin_y + self.height:
            coin_total += 1
            self.display = False
            coin_collect_sfx.play()
            
coin1 = Coin(810,160,30,30,"coin.png",True)
coin2 = Coin(1000,100,30,30,"coin.png",True)
coin3 = Coin(1680,80,30,30,"coin.png",True)
coin4 = Coin(2500,160,30,30,"coin.png",True)

class Platform():
    def __init__(self,object_x,object_y,object_width,object_height,spriteFileName):
        self.object_x = object_x
        self.object_y = object_y 
        self.object_width = object_width
        self.object_height = object_height 
        self.object_image = pygame.image.load(spriteFileName)

    def blit(self,object_x,object_y):
        self.object_x = object_x
        self.object_y = object_y
        screen.blit(self.object_image, (object_x,object_y))

    def interact(self, object_x,object_y,object_height):
        global gravity_speed
        global character_height
        global character_width
        global horizontal_velocity
        self.object_x = object_x
        self.object_y = object_y 
        self.object_height = object_height
        if pario.y + character_height > object_y and pario.x + 20 >= object_x and pario.x < object_x + 40 and pario.y < object_y - 40:
            pario.gravity(False)
            pario.jumping = False
        else:
            pario.gravity(True)

    def vertical_recoil(self, object_x, object_y, object_height):
        global gravity_speed
        global character_height
        global character_width
        global horizontal_velocity
        global vertical_velocity 
        self.object_x = object_x
        self.object_y = object_y 
        self.object_height = object_height
        if pario.x + character_width >= object_x and pario.x < object_x + 45 and pario.y <= object_y + object_height and pario.y >= object_y + object_height - 10:
            vertical_velocity = 0 
        else:
            vertical_velocity = 10
    
    def horizontal_recoil(self, object_x, object_y, object_height):
        global gravity_speed
        global character_height
        global character_width
        global horizontal_velocity
        global vertical_velocity 
        self.object_x = object_x
        self.object_y = object_y
        self.object_height = object_height
        if pario.x + character_width >= object_x and pario.x + character_width <= object_x + 10 and pario.y <= object_y + object_height and pario.y + character_height >= object_y:
            pario.x -= 5
        elif pario.x >= object_x + 30 and pario.x < object_x + 50 and pario.y <= object_y + object_height and pario.y + character_height >= object_y:
            pario.x += 5
        else:
            horizontal_velocity = 3

object1 = Platform(600,300,50,50,"solid_flat_platform.png")
object2 = Platform(800,200,50,50,"solid_flat_platform.png")
object3 = Platform(1200,300,50,50,"solid_flat_platform.png")
object4 = Platform(1500,300,50,50,"solid_flat_platform.png")
object5 = Platform(1540,300,50,50,"solid_flat_platform.png")
object6 = Platform(2000,280,50,50,"solid_flat_platform.png")
object7 = Platform(2600,280,50,50,"solid_flat_platform.png")
object8 = Platform(3000,280,50,50,"solid_flat_platform.png")
object9 = Platform(3200,280,50,50,"solid_flat_platform.png")
object10 = Platform(4500,280,50,50,"solid_flat_platform.png")
flag1 = Platform(5700,350,50,50,"flag_pole.png")


def shift():
    global horizontal_velocity
    global shift_counter 
    global movement_unlocked
    if shift_counter < 5000:
        if pario.x > 500:
            horizontal_velocity = 0 
            if keys[pygame.K_a]:
                shift_counter -= 3
            if keys[pygame.K_d] and keys[pygame.K_a] != True:
                object1.object_x -= 3
                object2.object_x -= 3
                object3.object_x -= 3
                object4.object_x -= 3
                object5.object_x -= 3
                object6.object_x -= 3
                object7.object_x -= 3
                object8.object_x -= 3
                object9.object_x -= 3
                object10.object_x -= 3
                coin1.coin_x -= 3
                coin2.coin_x -=3
                coin3.coin_x -= 3
                coin4.coin_x -= 3
                fireball1.x -= 3
                fireball2.x -=3
                fireball3.x -= 3
                fireball4.x -=3 
                fireball5.x -= 3
                flag1.object_x -= 3
                shift_counter += 3
            else: 
                horizontal_velocity = 3
    else:
        horizontal_velocity = 3
        movement_unlocked = True

object1.object_x = 600
object1.object_y = 300
object2.object_x = 800
object2.object_y = 200
object3.object_x = 1500
object3.object_y = 300
object4.object_x = 2000
object4.object_y = 300 
object5.object_x = 2400
object5.object_y = 300
object6.object_x = 3000
object6.object_y = 300 
object7.object_x = 3400
object7.object_y = 300 
object8.object_x = 3500
object8.object_y = 300 
object9.object_x = 3800
object9.object_y = 300 
object10.object_x = 4500
object10.object_y = 300 
flag1.object_x = 5700
flag1.object_y = 350


class Background():
    def __init__(self,background_image):
        global size
        self.background_image = pygame.image.load(background_image)
        self.bgx = 0
        self.bgy = 0 
        self.background_width = self.background_image.get_width()
        self.background_tiles = math.ceil (size[0] / size[1]) + 1 
        
    def update(self):
        global ground_scroll
        global background_velocity
        if pario.x > 500:
            if keys[pygame.K_d] and self.bgx < wall - character_width and keys[pygame.K_a] != True:
                ground_scroll -= 3
                background_velocity -= 1
                
    def render(self):
        global background_velocity
        for i in range(0, self.background_tiles):
            screen.blit(self.background_image, (i * self.background_width + background_velocity, 0))
        
        if abs(background_velocity) > self.background_width:
            background_velocity = 0 

back_ground = Background("backgroundimage.png")

class Enemy():
    def __init__(self,name,x,y,sprite):
        self.name = name
        self.x = x
        self.y = y 
        self.enemyImage = pygame.image.load(sprite)

    def movement(self,flag):
        if flag == True:
            if pario.x > self.x:
                self.x += 0.85
            if pario.x < self.x:
                self.x -= 0.85
            if pario.y > self.y:
                self.y += 0.85
            if pario.y < self.y:
                self.y -= 0.85

    def blit(self,x, y):
        self.x = x
        self.y = y
        screen.blit(self.enemyImage, (x,y))

    def gravity(self,fall):
        global gravity_speed  
        self.fall = fall
        fall = True
        if self.y < floor - character_height and self.fall == True:
            self.y += gravity_speed
    
    def interact(self):
        global done
        global enemy_height
        if pario.x + 40 >= self.x and pario.x <= self.x + 60 and pario.y - 20 <= self.y and pario.y >= (self.y - 80):
            if pario.lives >= 1:
                pario.lives -= 1
                
                # Only play the sound exactly when a visual heart is lost
                if pario.lives == 40 or pario.lives == 20:
                    damage_sfx.play() 
                    
                return True

fireball1 = Enemy("fire",1000,330,"fireball.png")
fireball2 = Enemy("fire",2000,330,"fireball.png")
fireball3 = Enemy("fire",3410,370,"fireball.png")
fireball4 = Enemy("fire",2500,300,"fireball.png")
fireball5 = Enemy("fire",6000,300,"fireball.png")


def level_two():
# Main loop for the game
    global run
    global keys
    global pos
    global left
    global done
    global passed
    global y
    global x
    global gravity_speed
    global event
    global instant_quit
    global main_menu
    global muted_jump_sfx
    global player_lost
    global ground_tiles 
    global ground_width
    global ground_scroll
    global level_complete_sfx

    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
                instant_quit = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause()

        if main_menu == True:
            break
            
        keys = pygame.key.get_pressed()

        if pario.jumping == False and keys[pygame.K_w]:
            muted_jump_sfx.play()

        back_ground.render()
        if shift_counter < 5000:
            back_ground.update()

        x = pario.x
        y = pario.y

        for i in range(0, ground_tiles):
            screen.blit(ground, (i * ground_width + ground_scroll, 450))
 
        if abs(ground_scroll)  >  ground_width:
            ground_scroll = 0

        flag1.blit(flag1.object_x,flag1.object_y)

        # Coins
        if coin1.display == True:
            coin1.collect()
            coin1.blit(coin1.coin_x,coin1.coin_y)

        if coin2.display == True:
            coin2.collect()
            coin2.blit(coin2.coin_x,coin2.coin_y)
        
        if coin3.display == True:
            coin3.collect()
            coin3.blit(coin3.coin_x,coin3.coin_y)
        
        if coin4.display == True:
            coin4.collect()
            coin4.blit(coin4.coin_x,coin4.coin_y)

        # Character functions
        pario.blit(x,y)
        pario.movement(True)
        
        if keys[pygame.K_a] and keys[pygame.K_d]:
            pario.idle()
        elif keys[pygame.K_d] and pario.jumping == False: 
            pario.right_run()
        elif keys[pygame.K_a] and pario.jumping == False: 
            pario.left_run()
        elif keys[pygame.K_w]:
            pario.jump()
        else:
            pario.idle()

        # Platforms
        object1.blit(object1.object_x,object1.object_y)
        object2.blit(object2.object_x,object2.object_y)
        object3.blit(object3.object_x,object3.object_y)
        object4.blit(object4.object_x, object4.object_y)
        object5.blit(object5.object_x, object5.object_y)
        object6.blit(object6.object_x,object6.object_y)
        object7.blit(object7.object_x,object7.object_y)
        object8.blit(object8.object_x,object8.object_y)
        object9.blit(object9.object_x,object9.object_y)
        object10.blit(object10.object_x,object10.object_y)
        
        if pario.x >= object1.object_x - 20 and pario.x <= object1.object_x + 50: passed = 0 
        elif pario.x >= object2.object_x - 20 and pario.x <= object2.object_x + 50: passed = 1
        elif pario.x >= object3.object_x - 10 and pario.x <= object3.object_x + 20: passed = 2
        elif pario.x >= object4.object_x - 10 and pario.x <= object4.object_x + 20: passed = 3
        elif pario.x >= object5.object_x - 10 and pario.x <= object5.object_x + 20: passed = 4
        elif pario.x >= object5.object_x - 10 and pario.x <= object6.object_x + 20: passed = 5
        elif pario.x >= object6.object_x - 10 and pario.x <= object7.object_x + 20: passed = 6
        elif pario.x >= object7.object_x - 10 and pario.x <= object8.object_x + 20: passed = 7
        elif pario.x >= object8.object_x - 10 and pario.x <= object9.object_x + 20: passed = 8
        elif pario.x >= object9.object_x - 10 and pario.x <= object10.object_x + 20: passed = 9
        
        if passed == 0:
            object1.interact(object1.object_x,object1.object_y,50)
            object1.vertical_recoil(object1.object_x,object1.object_y,50)
            object1.horizontal_recoil(object1.object_x,object1.object_y,50)
        elif passed == 1:
            object2.interact(object2.object_x,object2.object_y,50)
            object2.vertical_recoil(object2.object_x,object2.object_y,50)
            object2.horizontal_recoil(object2.object_x,object2.object_y,50)
        elif passed == 2:
            object3.interact(object3.object_x,object3.object_y,50)
            object3.vertical_recoil(object3.object_x,object3.object_y,50)
            object3.horizontal_recoil(object3.object_x,object3.object_y,50)
        elif passed == 3:
            object4.interact(object4.object_x,object4.object_y,50)
            object4.vertical_recoil(object4.object_x,object4.object_y,50)
            object4.horizontal_recoil(object4.object_x,object4.object_y,50)
        elif passed == 4:
            object5.interact(object5.object_x,object5.object_y,50)
            object5.vertical_recoil(object5.object_x,object5.object_y,50)
            object5.horizontal_recoil(object5.object_x,object5.object_y,50)
        elif passed == 5:
            object6.interact(object6.object_x,object6.object_y,50)
            object6.vertical_recoil(object6.object_x,object6.object_y,50)
            object6.horizontal_recoil(object6.object_x,object6.object_y,50)
        elif passed == 6:
            object7.interact(object7.object_x,object7.object_y,50)
            object7.vertical_recoil(object7.object_x,object7.object_y,50)
            object7.horizontal_recoil(object7.object_x,object7.object_y,50)
        elif passed == 7:
            object8.interact(object8.object_x,object8.object_y,50)
            object8.vertical_recoil(object8.object_x,object8.object_y,50)
            object8.horizontal_recoil(object8.object_x,object8.object_y,50)
        elif passed == 8:
            object9.interact(object9.object_x,object9.object_y,50)
            object9.vertical_recoil(object9.object_x,object9.object_y,50)
            object9.horizontal_recoil(object9.object_x,object9.object_y,50)
        elif passed == 9:
            object10.interact(object10.object_x,object10.object_y,50)
            object10.vertical_recoil(object10.object_x,object10.object_y,50)
            object10.horizontal_recoil(object10.object_x,object10.object_y,50)
        
        shift()
       
        health(pario)
        pos = pygame.mouse.get_pos()
        left = pygame.mouse.get_pressed()

        # Fireball enemies
        #x = fireball1.x; y = fireball1.y
        #fireball1.blit(x,y); fireball1.movement(True); fireball1.interact() 

        x = fireball2.x; y = fireball2.y
        fireball2.blit(x,y); fireball2.movement(True); fireball2.interact() 

        #x = fireball3.x; y = fireball3.y
        #fireball3.blit(x,y); fireball3.movement(False); fireball3.interact() 

        x = fireball4.x; y = fireball4.y
        fireball4.blit(x,y); fireball4.movement(True); fireball4.interact() 

        x = fireball5.x; y = fireball5.y
        fireball5.blit(x,y); fireball5.movement(True); fireball5.interact() 

        # Player Loss Condition
        if pario.lives <= 0:
            player_lost = True
            damage_sfx.stop()
            game_over_sfx.play() # Plays game over sound effect
            break

        if pario.jumping == True:
            gravity_speed += 0.105
        else:
            gravity_speed = 4

        # Win Condition
        if pario.x >= 650:
            level_complete_sfx.play()
            break 

        pygame.display.update()


# Master Flow Control
async def main_program():
    global main_menu
    global shift_counter
    global positioning
    global player_lost
    global instructions_complete

    while instant_quit == False:
        # Reset menu flags
        main_menu = False
        instructions_complete = False
        player_lost = False
        
        # 1. Main Menu
        loading_screen()
        
        if instant_quit:
            break

        # 2. Instructions Screen (Requires SPACE to pass)
        instructions()
        
        if instant_quit:
            break

        # 3. Enter Level 2 directly
        level_two() 

        if instant_quit:
            break
            
        # 4. End Game Screen (Only run if they didn't manually quit to main menu from pause)
        if main_menu == False:
            game_over()

        # 5. Reset all objects to exact starting state for next loop
        pario.lives = 60
        pario.x = 200
        pario.y = 260
        shift_counter = 0

        object1.object_x = 600; object1.object_y = 300
        object2.object_x = 800; object2.object_y = 200
        object3.object_x = 1500; object3.object_y = 280
        object4.object_x = 2000; object4.object_y = 280 
        object5.object_x = 2400; object5.object_y = 280
        object6.object_x = 3000; object6.object_y = 280 
        object7.object_x = 3400; object7.object_y = 280 
        object8.object_x = 3500; object8.object_y = 280 
        object9.object_x = 3800; object9.object_y = 280 
        object10.object_x = 4500; object10.object_y = 280 
        
        flag1.object_x = 5700; flag1.object_y = 350

        coin1.coin_x = 810; coin1.coin_y = 160; coin1.display = True
        coin2.coin_x = 1000; coin2.coin_y = 100; coin2.display = True
        coin3.coin_x = 1680; coin3.coin_y = 80; coin3.display = True
        coin4.coin_x = 2500; coin4.coin_y = 160; coin4.display = True

        fireball1.x = 1000; fireball1.y = 330
        fireball2.x = 1500; fireball2.y = 330
        fireball3.x = 3410; fireball3.y = 370
        fireball4.x = 2500; fireball4.y = 300
        fireball5.x = 6000; fireball5.y = 300

        back_ground.bgx = 0
        back_ground.bgy = 0
        positioning = False
        main_menu = False

        pygame.display.flip()
        clock.tick(24)
        await asyncio.sleep(0)


asyncio.run(main_program())

#main_program()

#pygame.display.flip()
#clock.tick(20)
